import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ProductswallshelvesComponent } from './productswallshelves.component';

describe('ProductswallshelvesComponent', () => {
  let component: ProductswallshelvesComponent;
  let fixture: ComponentFixture<ProductswallshelvesComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ProductswallshelvesComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ProductswallshelvesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
