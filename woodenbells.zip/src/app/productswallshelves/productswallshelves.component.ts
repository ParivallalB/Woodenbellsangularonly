import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-productswallshelves',
  templateUrl: './productswallshelves.component.html',
  styleUrls: ['./productswallshelves.component.css']
})
export class ProductswallshelvesComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
