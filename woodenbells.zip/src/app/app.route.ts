import {Routes} from "@angular/router";
import { HomeComponent } from './home/home.component';
import { AboutComponent } from './about/about.component';
import { ServiceComponent } from './service/service.component';
import { ContactComponent } from './contact/contact.component';
import { ProductsComponent } from './products/products.component';

import { ProductstablesComponent } from './productstables/productstables.component';
import { ProductscotsComponent } from './productscots/productscots.component';
import { ProductswallshelvesComponent } from './productswallshelves/productswallshelves.component';
import { ProductsBookshelfComponent } from './products-bookshelf/products-bookshelf.component';
import { ProductsShoeracksComponent } from './products-shoeracks/products-shoeracks.component';
import { ProductsWardrobesComponent } from './products-wardrobes/products-wardrobes.component';
export const Approute:Routes=[
    {
    path:"",
    component:HomeComponent
    },
    {
        path:"about",
        component:AboutComponent
        },
        {
            path:"service",
            component:ServiceComponent
            },
            {
                path:"products",
                component:ProductsComponent
                },
                {
                    path:"productstables",
                    component:ProductstablesComponent
                    },
                    {
                        path:"productscots",
                        component:ProductscotsComponent
                        },
                        {
                            path:"productsWallshelves",
                            component:ProductswallshelvesComponent
                            },
                            {
                                path:"productsBookshelf",
                                component:ProductsBookshelfComponent
                                },
                                {
                                    path:"productsShoeracks",
                                    component:ProductsShoeracksComponent
                                    },
                                    {
                                        path:"productsWardrobes",
                                        component:ProductsWardrobesComponent
                                        },
                                    
            {
                path:"contact",
                component:ContactComponent
                },

]