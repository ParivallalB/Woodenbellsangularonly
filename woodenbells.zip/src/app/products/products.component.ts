import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-products',
  templateUrl: './products.component.html',
  styleUrls: ['./products.component.css']
})
export class ProductsComponent implements OnInit {
public showtables=true;
public showcots=true;
  constructor() { }

  ngOnInit() {
  }
  allproductsclick(){
    this.showcots=true;
    this.showtables=true;
  }
  tableclick(){
    this.showcots=false;
    this.showtables=true;
  }
  cotsclick(){
    this.showcots=true;
    this.showtables=false;
  }

}
