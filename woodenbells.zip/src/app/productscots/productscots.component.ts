import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-productscots',
  templateUrl: './productscots.component.html',
  styleUrls: ['./productscots.component.css']
})
export class ProductscotsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
