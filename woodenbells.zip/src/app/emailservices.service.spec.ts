import { TestBed, inject } from '@angular/core/testing';

import { EmailservicesService } from './emailservices.service';

describe('EmailservicesService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [EmailservicesService]
    });
  });

  it('should be created', inject([EmailservicesService], (service: EmailservicesService) => {
    expect(service).toBeTruthy();
  }));
});
