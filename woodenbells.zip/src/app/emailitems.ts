export class emailitems{
    from:string;
    to:string;
    phone:string;
    subject:string;
    text:string
}