import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { SliderModule } from 'angular-image-slider';
import { AppComponent } from './app.component';
import { TopnavbarComponent } from './topnavbar/topnavbar.component';
import { HomeComponent } from './home/home.component';
import { AboutComponent } from './about/about.component';
import { ServiceComponent } from './service/service.component';
import { ContactComponent } from './contact/contact.component';
import {Approute} from "./app.route";
import {RouterModule} from "@angular/router";
import { FooterComponent } from './footer/footer.component';
import { ProductsComponent } from './products/products.component';
import { ProductstablesComponent } from './productstables/productstables.component';
import { ProductscotsComponent } from './productscots/productscots.component';
import { ProductswallshelvesComponent } from './productswallshelves/productswallshelves.component';
import { ProductsBookshelfComponent } from './products-bookshelf/products-bookshelf.component';
import { ProductsShoeracksComponent } from './products-shoeracks/products-shoeracks.component';
import { ProductsWardrobesComponent } from './products-wardrobes/products-wardrobes.component';


@NgModule({
  declarations: [
    AppComponent,
    TopnavbarComponent,
    HomeComponent,
    AboutComponent,
    ServiceComponent,
    ContactComponent,
    FooterComponent,
    ProductsComponent,
    ProductstablesComponent,
    ProductscotsComponent,
    ProductswallshelvesComponent,
    ProductsBookshelfComponent,
    ProductsShoeracksComponent,
    ProductsWardrobesComponent
  ],
  imports: [
    BrowserModule,
    HttpClientModule,
    FormsModule,
    BrowserAnimationsModule,
    SliderModule,
    RouterModule.forRoot(Approute)
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
