import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-products-wardrobes',
  templateUrl: './products-wardrobes.component.html',
  styleUrls: ['./products-wardrobes.component.css']
})
export class ProductsWardrobesComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
