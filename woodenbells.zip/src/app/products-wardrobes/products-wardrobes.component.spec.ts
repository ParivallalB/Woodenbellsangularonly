import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ProductsWardrobesComponent } from './products-wardrobes.component';

describe('ProductsWardrobesComponent', () => {
  let component: ProductsWardrobesComponent;
  let fixture: ComponentFixture<ProductsWardrobesComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ProductsWardrobesComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ProductsWardrobesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
