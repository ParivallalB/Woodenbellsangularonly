import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-productstables',
  templateUrl: './productstables.component.html',
  styleUrls: ['./productstables.component.css']
})
export class ProductstablesComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
