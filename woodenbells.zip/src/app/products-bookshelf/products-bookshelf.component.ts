import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-products-bookshelf',
  templateUrl: './products-bookshelf.component.html',
  styleUrls: ['./products-bookshelf.component.css']
})
export class ProductsBookshelfComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
