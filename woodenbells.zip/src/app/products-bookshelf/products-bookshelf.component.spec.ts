import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ProductsBookshelfComponent } from './products-bookshelf.component';

describe('ProductsBookshelfComponent', () => {
  let component: ProductsBookshelfComponent;
  let fixture: ComponentFixture<ProductsBookshelfComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ProductsBookshelfComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ProductsBookshelfComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
