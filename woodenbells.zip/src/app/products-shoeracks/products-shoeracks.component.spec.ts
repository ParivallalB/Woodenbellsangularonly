import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ProductsShoeracksComponent } from './products-shoeracks.component';

describe('ProductsShoeracksComponent', () => {
  let component: ProductsShoeracksComponent;
  let fixture: ComponentFixture<ProductsShoeracksComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ProductsShoeracksComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ProductsShoeracksComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
