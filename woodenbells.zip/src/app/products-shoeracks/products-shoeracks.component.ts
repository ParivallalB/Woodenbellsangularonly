import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-products-shoeracks',
  templateUrl: './products-shoeracks.component.html',
  styleUrls: ['./products-shoeracks.component.css']
})
export class ProductsShoeracksComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
